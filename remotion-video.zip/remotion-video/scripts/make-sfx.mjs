// Synthesizes the small UI sound kit into public/sfx/*.wav (16-bit mono, 44.1 kHz). No downloads needed.
// Run: node scripts/make-sfx.mjs
import fs from "node:fs";
import path from "node:path";

const SR = 44100;
const OUT = path.join(process.cwd(), "public", "sfx");
fs.mkdirSync(OUT, { recursive: true });

let seed = 1234567;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 4294967296 * 2 - 1;
};

const buf = (sec) => new Float32Array(Math.floor(sec * SR));
const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  return x.map((v) => (y += a * (v - y)));
};
const highpass = (x, fc) => {
  const lp = lowpass(x, fc);
  return x.map((v, i) => v - lp[i]);
};
// state-variable band-pass with time-varying centre frequency
const bandpassSweep = (x, f0, f1, q) => {
  let low = 0, band = 0;
  return x.map((v, i) => {
    const k = i / x.length;
    const f = f0 * Math.pow(f1 / f0, k);
    const g = 2 * Math.sin((Math.PI * f) / SR);
    const hp = v - low - band / q;
    band += g * hp;
    low += g * band;
    return band;
  });
};
// very small reverb: three combs + one allpass, low wet level
const reverb = (x, wet = 0.12, tail = 0.12) => {
  const out = new Float32Array(x.length + Math.floor(tail * SR));
  out.set(x);
  const wetBuf = new Float32Array(out.length);
  for (const [ms, fb] of [[29.7, 0.32], [37.1, 0.3], [41.1, 0.28]]) {
    const d = Math.floor((ms / 1000) * SR);
    const c = new Float32Array(out.length);
    for (let i = 0; i < out.length; i++) {
      const dry = i < x.length ? x[i] : 0;
      c[i] = dry + (i >= d ? c[i - d] * fb : 0);
      wetBuf[i] += c[i] / 3;
    }
  }
  for (let i = 0; i < out.length; i++) out[i] = x[i] !== undefined ? x[i] + wetBuf[i] * wet : wetBuf[i] * wet;
  return out;
};
const fade = (x, inMs, outMs) => {
  const a = Math.floor((inMs / 1000) * SR), b = Math.floor((outMs / 1000) * SR);
  for (let i = 0; i < a && i < x.length; i++) x[i] *= i / a;
  for (let i = 0; i < b && i < x.length; i++) x[x.length - 1 - i] *= i / b;
  return x;
};
const env = (i, att, tau) => {
  const t = i / SR;
  return (t < att ? t / att : 1) * Math.exp(-Math.max(0, t - att) / tau);
};

const sounds = {
  // soft pop: quickly falling sine + tiny envelope
  pop: () => {
    const x = buf(0.2);
    let ph = 0;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      const f = 170 + 420 * Math.exp(-t / 0.028);
      ph += (2 * Math.PI * f) / SR;
      x[i] = (Math.sin(ph) + 0.18 * Math.sin(2 * ph)) * env(i, 0.004, 0.05);
    }
    return fade(reverb(lowpass(x, 4200), 0.1, 0.08), 2, 40);
  },
  // crisp click: short high-passed noise burst + tiny tick
  click: () => {
    const x = buf(0.1);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      x[i] = (rnd() * 0.9 + 0.5 * Math.sin(2 * Math.PI * 1900 * t)) * env(i, 0.0008, 0.009);
    }
    return fade(reverb(lowpass(highpass(x, 2200), 7500), 0.08, 0.05), 1, 30);
  },
  // soft whoosh: band-pass noise sweep, slow fade in/out
  whoosh: () => {
    const n = buf(0.68);
    for (let i = 0; i < n.length; i++) n[i] = rnd();
    const x = bandpassSweep(n, 350, 2600, 1.6);
    for (let i = 0; i < x.length; i++) {
      const k = i / x.length;
      x[i] *= Math.pow(Math.sin(Math.PI * Math.pow(k, 0.7)), 2);
    }
    return fade(reverb(lowpass(x, 5500), 0.1, 0.1), 5, 80);
  },
  // swipe: shorter, brighter sweep for scene transitions
  swipe: () => {
    const n = buf(0.4);
    for (let i = 0; i < n.length; i++) n[i] = rnd();
    const x = bandpassSweep(n, 900, 4200, 2.2);
    for (let i = 0; i < x.length; i++) {
      const k = i / x.length;
      x[i] *= Math.pow(Math.sin(Math.PI * Math.pow(k, 0.6)), 2);
    }
    return fade(reverb(lowpass(x, 6500), 0.08, 0.08), 4, 70);
  },
  // chime / pluck: soft overtones, short decay
  chime: () => {
    const x = buf(0.42);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      const f = 784;
      x[i] =
        (Math.sin(2 * Math.PI * f * t) * 1 * env(i, 0.005, 0.11) +
          Math.sin(2 * Math.PI * f * 2 * t) * 0.32 * env(i, 0.005, 0.07) +
          Math.sin(2 * Math.PI * f * 3 * t) * 0.1 * env(i, 0.005, 0.045) +
          Math.sin(2 * Math.PI * f * 2.76 * t) * 0.06 * env(i, 0.005, 0.03));
    }
    return fade(reverb(lowpass(x, 5200), 0.14, 0.12), 3, 70);
  },
  // restrained soft thud for the hook / key message
  thud: () => {
    const x = buf(0.36);
    let ph = 0;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      const f = 46 + 40 * Math.exp(-t / 0.05);
      ph += (2 * Math.PI * f) / SR;
      x[i] = Math.sin(ph) * env(i, 0.006, 0.09);
    }
    return fade(reverb(lowpass(x, 420), 0.08, 0.06), 4, 60);
  },
};

// Level matching: equal RMS over the audible part, peak capped below clipping.
const TARGET_RMS = 0.15;
const PEAK_CAP = 0.89;
const report = [];
for (const [name, make] of Object.entries(sounds)) {
  let x = make();
  const peak0 = x.reduce((m, v) => Math.max(m, Math.abs(v)), 0);
  const thr = peak0 * 0.05;
  let sum = 0, cnt = 0;
  for (const v of x) if (Math.abs(v) > thr) { sum += v * v; cnt++; }
  const rms0 = Math.sqrt(sum / Math.max(1, cnt));
  let gain = TARGET_RMS / rms0;
  if (peak0 * gain > PEAK_CAP) gain = PEAK_CAP / peak0;
  x = x.map((v) => v * gain);

  const pcm = Buffer.alloc(44 + x.length * 2);
  pcm.write("RIFF", 0); pcm.writeUInt32LE(36 + x.length * 2, 4); pcm.write("WAVE", 8);
  pcm.write("fmt ", 12); pcm.writeUInt32LE(16, 16); pcm.writeUInt16LE(1, 20); pcm.writeUInt16LE(1, 22);
  pcm.writeUInt32LE(SR, 24); pcm.writeUInt32LE(SR * 2, 28); pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34);
  pcm.write("data", 36); pcm.writeUInt32LE(x.length * 2, 40);
  for (let i = 0; i < x.length; i++) pcm.writeInt16LE(Math.max(-32767, Math.min(32767, Math.round(x[i] * 32767))), 44 + i * 2);
  fs.writeFileSync(path.join(OUT, `${name}.wav`), pcm);
  report.push(name);
}
console.log("sfx written:", report.join(", "));
