// timing.ts — every frame number in the video is derived from the SRT (src/srt.ts).
import { SRT } from "./srt";
import { FPS } from "./config";

export type Cue = { n: number; startMs: number; endMs: number; text: string; start: number; end: number; len: number };

const toMs = (t: string) => {
  const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) throw new Error(`Bad SRT time: ${t}`);
  return ((Number(m[1]) * 60 + Number(m[2])) * 60 + Number(m[3])) * 1000 + Number(m[4]);
};

export const parseSrt = (src: string): Cue[] =>
  src
    .replace(/^\uFEFF/, "")
    .replace(/\r/g, "")
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split("\n");
      const [a, b] = lines[1].split("-->");
      const startMs = toMs(a);
      const endMs = toMs(b);
      const start = Math.round((startMs / 1000) * FPS);
      const end = Math.round((endMs / 1000) * FPS);
      return { n: parseInt(lines[0], 10), startMs, endMs, text: lines.slice(2).join(" "), start, end, len: end - start };
    });

export const cues = parseSrt(SRT);
export const cue = (n: number): Cue => {
  const c = cues.find((x) => x.n === n);
  if (!c) throw new Error(`No cue ${n}`);
  return c;
};

/** Total length = end of the last cue (SRT wins over any audio length). */
export const TOTAL_FRAMES = Math.ceil((cues[cues.length - 1].endMs / 1000) * FPS);

/** Visuals enter this many frames BEFORE the matching words are spoken. */
export const LEAD = 5;
/** Scene exit length (faster than entrances). */
export const EXIT = 10;

export type SceneId = "hook" | "compare" | "intro" | "question" | "build" | "features" | "subscribe" | "outro";

// Scene boundaries always sit on cue boundaries; a scene can span several cues.
const DEFS: { id: SceneId; cues: number[] }[] = [
  { id: "hook", cues: [1, 2] },
  { id: "compare", cues: [3, 4] },
  { id: "intro", cues: [5] },
  { id: "question", cues: [6] },
  { id: "build", cues: [7] },
  { id: "features", cues: [8, 9] },
  { id: "subscribe", cues: [10] },
  { id: "outro", cues: [11] },
];

export type SceneTiming = {
  id: SceneId;
  from: number; // composition frame where this scene's Sequence starts
  dur: number; // Sequence length in frames
  /** local frame where an item should START for cue n (item k of count), LEAD frames before the voice */
  at: (n: number, k?: number, count?: number) => number;
  /** local frame where cue n's voice starts / ends */
  voiceStart: (n: number) => number;
  voiceEnd: (n: number) => number;
  /** cue length in frames */
  len: (n: number) => number;
};

export const scenes: SceneTiming[] = DEFS.map((d, i) => {
  const first = cue(d.cues[0]);
  const anchor = i === 0 ? 0 : first.start;
  const from = Math.max(0, anchor - LEAD);
  const next = DEFS[i + 1] ? cue(DEFS[i + 1].cues[0]).start : TOTAL_FRAMES;
  const to = i === DEFS.length - 1 ? TOTAL_FRAMES : Math.min(TOTAL_FRAMES, next + LEAD);
  return {
    id: d.id,
    from,
    dur: to - from,
    at: (n, k = 0, count = 1) => {
      const c = cue(n);
      // several items inside ONE cue are spaced equally across that cue
      return Math.max(0, Math.round(c.start + (k / count) * c.len - from - LEAD));
    },
    voiceStart: (n) => cue(n).start - from,
    voiceEnd: (n) => cue(n).end - from,
    len: (n) => cue(n).len,
  };
});

export const sceneById = (id: SceneId): SceneTiming => scenes.find((s) => s.id === id)!;
