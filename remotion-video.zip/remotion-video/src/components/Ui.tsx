import React from "react";
import { Img, interpolate, staticFile, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { SceneId, sceneById } from "../timing";

const c = theme.colors;

export const GlassCard: React.FC<{ width?: number | string; height?: number | string; radius?: number; style?: React.CSSProperties; children?: React.ReactNode }> = ({
  width,
  height,
  radius = theme.radius.md,
  style,
  children,
}) => (
  <div
    style={{
      width,
      height,
      borderRadius: radius,
      background: `linear-gradient(160deg, ${c.surfaceStrong}, ${c.surface})`,
      border: `1px solid ${c.hairline}`,
      boxShadow: theme.shadow.card,
      backdropFilter: "blur(18px)",
      position: "relative",
      overflow: "hidden",
      ...style,
    }}
  >
    {children}
  </div>
);

/** Glossy browser window frame. */
export const BrowserFrame: React.FC<{ width: number; height: number; style?: React.CSSProperties; children?: React.ReactNode }> = ({ width, height, style, children }) => (
  <div
    style={{
      width,
      height,
      borderRadius: theme.radius.md,
      background: c.bgAlt,
      border: `1px solid ${c.hairline}`,
      boxShadow: theme.shadow.card,
      overflow: "hidden",
      position: "relative",
      ...style,
    }}
  >
    <div style={{ height: 56, display: "flex", alignItems: "center", gap: 10, padding: "0 22px", borderBottom: `1px solid ${c.hairline}`, background: c.surface }}>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{ width: 13, height: 13, borderRadius: 13, background: c.textFaint }} />
      ))}
      <div style={{ marginLeft: 22, height: 26, width: Math.round(width * 0.36), borderRadius: 13, background: c.surfaceStrong }} />
    </div>
    <div style={{ position: "relative", width, height: height - 56 }}>{children}</div>
    <div style={{ position: "absolute", inset: 0, pointerEvents: "none", background: `linear-gradient(120deg, ${c.glowSoft}, transparent 34%)`, opacity: 0.55 }} />
  </div>
);

/** Plain rounded block used by wireframes / mock UIs. */
export const Block: React.FC<{ w: number | string; h: number | string; r?: number; fill?: string; style?: React.CSSProperties; children?: React.ReactNode }> = ({
  w,
  h,
  r = 12,
  fill = c.surfaceStrong,
  style,
  children,
}) => <div style={{ width: w, height: h, borderRadius: r, background: fill, flexShrink: 0, ...style }}>{children}</div>;

type IconProps = { size?: number; color?: string; draw?: number };
const svgBase = (size: number) => ({ width: size, height: size, viewBox: "0 0 48 48", fill: "none", strokeLinecap: "round" as const, strokeLinejoin: "round" as const });

export const IconCheck: React.FC<IconProps> = ({ size = 48, color = c.text, draw = 1 }) => (
  <svg {...svgBase(size)} stroke={color} strokeWidth={5}>
    <path d="M10 25 L20 35 L38 14" strokeDasharray={50} strokeDashoffset={50 * (1 - draw)} />
  </svg>
);
export const IconShield: React.FC<IconProps> = ({ size = 48, color = c.text, draw = 1 }) => (
  <svg {...svgBase(size)} stroke={color} strokeWidth={3.4}>
    <path d="M24 5 L39 11 V23 C39 33 32 40 24 43 C16 40 9 33 9 23 V11 Z" />
    <path d="M16 24 L22 30 L32 18" strokeDasharray={40} strokeDashoffset={40 * (1 - draw)} />
  </svg>
);
export const IconCode: React.FC<IconProps> = ({ size = 48, color = c.text }) => (
  <svg {...svgBase(size)} stroke={color} strokeWidth={3.6}>
    <path d="M17 14 L7 24 L17 34" />
    <path d="M31 14 L41 24 L31 34" />
    <path d="M27 9 L21 39" />
  </svg>
);
export const IconPhone: React.FC<IconProps> = ({ size = 48, color = c.text }) => (
  <svg {...svgBase(size)} stroke={color} strokeWidth={3.4}>
    <rect x="12" y="4" width="24" height="40" rx="6" />
    <path d="M21 38 H27" />
  </svg>
);
export const IconPlay: React.FC<IconProps> = ({ size = 48, color = c.text }) => (
  <svg {...svgBase(size)} stroke={color} strokeWidth={3.4}>
    <path d="M18 12 L36 24 L18 36 Z" fill={color} />
  </svg>
);
export const IconChat: React.FC<IconProps> = ({ size = 48, color = c.text }) => (
  <svg {...svgBase(size)} stroke={color} strokeWidth={3.4}>
    <path d="M8 10 H40 V31 H24 L14 40 V31 H8 Z" />
    <path d="M16 19 H32 M16 25 H27" />
  </svg>
);
export const IconBell: React.FC<IconProps> = ({ size = 48, color = c.text }) => (
  <svg {...svgBase(size)} stroke={color} strokeWidth={3.4}>
    <path d="M12 33 V22 C12 15 17 10 24 10 C31 10 36 15 36 22 V33 L40 37 H8 Z" />
    <path d="M20 42 H28" />
  </svg>
);
export const IconCursor: React.FC<IconProps> = ({ size = 48, color = c.text }) => (
  <svg {...svgBase(size)} stroke={c.bg} strokeWidth={2.5}>
    <path d="M10 6 L10 36 L18 29 L24 42 L30 39 L24 27 L35 27 Z" fill={color} />
  </svg>
);
export const IconBrowser: React.FC<IconProps> = ({ size = 48, color = c.text }) => (
  <svg {...svgBase(size)} stroke={color} strokeWidth={3.2}>
    <rect x="4" y="9" width="40" height="30" rx="5" />
    <path d="M4 18 H44" />
    <circle cx="10" cy="13.5" r="1.2" fill={color} />
    <circle cx="15" cy="13.5" r="1.2" fill={color} />
  </svg>
);

/** The user's profile picture, never distorted: circular crop, slow Ken Burns, float. */
export const Avatar: React.FC<{ size: number; scene: SceneId; ring?: boolean; glow?: boolean }> = ({ size, scene, ring = true, glow = true }) => {
  const frame = useCurrentFrame();
  const dur = sceneById(scene).dur;
  const zoom = interpolate(frame, [0, dur], [1.0, 1.09], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const pan = interpolate(frame, [0, dur], [0, -10], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const spin = frame * 0.25;
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      {ring && (
        <div
          style={{
            position: "absolute",
            inset: -Math.round(size * 0.07),
            borderRadius: "50%",
            border: `2px dashed ${c.hairline}`,
            transform: `rotate(${spin}deg)`,
          }}
        />
      )}
      <div
        style={{
          width: size,
          height: size,
          borderRadius: "50%",
          overflow: "hidden",
          border: `2px solid ${c.hairline}`,
          boxShadow: glow ? `0 0 ${Math.round(size * 0.22)}px ${c.glow}, ${theme.shadow.soft}` : theme.shadow.soft,
          background: c.bgAlt,
        }}
      >
        <Img src={staticFile("avatar.jpg")} style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${zoom}) translateX(${pan}px)` }} />
      </div>
    </div>
  );
};
