import React from "react";
import { Audio, Sequence, staticFile, useVideoConfig } from "remotion";
import { SFX_ENABLED } from "../config";

export type SfxName = "pop" | "click" | "whoosh" | "swipe" | "chime" | "thud";

// Max play length per sound (seconds) — all files are short with fast decay.
const LEN: Record<SfxName, number> = { pop: 0.4, click: 0.3, whoosh: 0.9, swipe: 0.7, chime: 0.7, thud: 0.6 };

/** One small sound at local frame `at` of the enclosing scene (place 2-5 frames before the visual lands). */
export const Sfx: React.FC<{ name: SfxName; at: number; volume?: number; rate?: number }> = ({
  name,
  at,
  volume = 0.28,
  rate = 1,
}) => {
  const { fps } = useVideoConfig();
  if (!SFX_ENABLED) return null;
  return (
    <Sequence from={Math.max(0, Math.round(at))} durationInFrames={Math.ceil(LEN[name] * fps)} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={volume} playbackRate={rate} />
    </Sequence>
  );
};
