import React, { useEffect, useState } from "react";
import { Audio, getRemotionEnvironment, staticFile } from "remotion";
import { VOICEOVER_IN_RENDER, VOICEOVER_PREVIEW } from "../config";

/**
 * Plays public/voiceover.mp3 if it exists (Studio preview). Missing file => silently nothing.
 * Switches: VOICEOVER_PREVIEW (Studio) and VOICEOVER_IN_RENDER (default false) in src/config.ts.
 */
export const PreviewAudio: React.FC<{ volume?: number }> = ({ volume = 1 }) => {
  const env = getRemotionEnvironment();
  const rendering = env.isRendering;
  const allowed = rendering ? VOICEOVER_IN_RENDER : VOICEOVER_PREVIEW;
  const [exists, setExists] = useState(false);

  useEffect(() => {
    if (!allowed) return;
    // When baking into a render the user opted in explicitly, so we trust the file is there.
    if (rendering) {
      setExists(true);
      return;
    }
    let alive = true;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        if (alive) setExists(r.ok && !type.includes("text/html"));
      })
      .catch(() => alive && setExists(false));
    return () => {
      alive = false;
    };
  }, [allowed, rendering]);

  if (!allowed || !exists) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={volume} />;
};
