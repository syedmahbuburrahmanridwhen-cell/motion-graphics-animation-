import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { EXIT, SceneId, sceneById } from "../timing";

/** Wraps every scene: animated exit (faster than entrances) that overlaps the next scene's lead-in. */
export const SceneShell: React.FC<{ id: SceneId; exit?: boolean; children: React.ReactNode }> = ({ id, exit = true, children }) => {
  const frame = useCurrentFrame();
  const dur = sceneById(id).dur;
  const p = exit
    ? interpolate(frame, [dur - EXIT, dur - 1], [0, 1], { easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" })
    : 0;
  return (
    <AbsoluteFill
      style={{
        opacity: 1 - p,
        transform: `translateY(${-20 * p}px) scale(${1 + 0.035 * p})`,
        filter: p > 0 ? `blur(${6 * p}px)` : undefined,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};
