import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

type SpringKey = keyof typeof theme.spring;
const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

/** Spring progress 0→1 starting at local frame `delay`. */
export const useSpring = (delay = 0, preset: SpringKey = "smooth") => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config: theme.spring[preset] });
};

/** Premium entrance: opacity + rise + scale + blur together. Never a lone fade. */
export const Pop: React.FC<{
  delay?: number;
  preset?: SpringKey;
  y?: number;
  x?: number;
  from?: number;
  blur?: number;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({ delay = 0, preset = "smooth", y = theme.motion.rise, x = 0, from = theme.motion.popScale, blur = 8, style, children }) => {
  const p = useSpring(delay, preset);
  const o = clamp01(p * 1.4);
  return (
    <div
      style={{
        opacity: o,
        transform: `translate(${interpolate(p, [0, 1], [x, 0])}px, ${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(p, [0, 1], [from, 1])})`,
        filter: blur ? `blur(${interpolate(o, [0, 1], [blur, 0])}px)` : undefined,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** Idle breathing for anything that stays on screen for more than ~2s. */
export const Float: React.FC<{ amp?: number; period?: number; phase?: number; scale?: number; style?: React.CSSProperties; children: React.ReactNode }> = ({
  amp = 6,
  period = 34,
  phase = 0,
  scale = 0.008,
  style,
  children,
}) => {
  const frame = useCurrentFrame();
  const s = Math.sin(frame / period + phase);
  return <div style={{ transform: `translateY(${s * amp}px) scale(${1 + s * scale})`, ...style }}>{children}</div>;
};

export type Part = string | { t: string; grad?: boolean; dim?: boolean; color?: string };

/**
 * Word-by-word staggered reveal. Splits ONLY on spaces — Bengali clusters (যুক্তাক্ষর, কার, রেফ)
 * are never broken. letterSpacing is always 0. Gaps are px, not em.
 */
export const Words: React.FC<{
  parts: Part[];
  size: number;
  delay?: number;
  per?: number;
  weight?: number;
  color?: string;
  dimColor?: string;
  gap?: number;
  align?: "flex-start" | "center" | "flex-end";
  maxWidth?: number;
  style?: React.CSSProperties;
}> = ({
  parts,
  size,
  delay = 0,
  per = theme.motion.wordGap,
  weight = theme.weights.hero,
  color = theme.colors.text,
  dimColor = theme.colors.textDim,
  gap,
  align = "flex-start",
  maxWidth,
  style,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const g = gap ?? Math.round(size * 0.26);
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        columnGap: g,
        rowGap: 0,
        justifyContent: align,
        maxWidth,
        fontFamily: theme.fonts.display,
        fontWeight: weight,
        fontSize: size,
        lineHeight: theme.lineHeight,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {parts.map((part, i) => {
        const p = typeof part === "string" ? { t: part } : part;
        const sp = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        const o = clamp01(sp * 1.5);
        const gradient: React.CSSProperties = p.grad
          ? {
              backgroundImage: `linear-gradient(180deg, ${theme.colors.primary} 35%, ${theme.colors.accent})`,
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              color: "transparent",
              WebkitTextFillColor: "transparent",
            }
          : {};
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              whiteSpace: "nowrap",
              opacity: o,
              transform: `translateY(${interpolate(sp, [0, 1], [theme.motion.rise, 0])}px) scale(${interpolate(sp, [0, 1], [theme.motion.popScale, 1])})`,
              filter: `blur(${interpolate(o, [0, 1], [theme.motion.blur, 0])}px)`,
              color: p.color ?? (p.dim ? dimColor : undefined),
              ...gradient,
            }}
          >
            {p.t}
          </span>
        );
      })}
    </div>
  );
};

/** Line mask reveal: the line slides up from inside a clipping box (padded so matras never clip). */
export const MaskLine: React.FC<{
  size: number;
  delay?: number;
  exitAt?: number;
  weight?: number;
  color?: string;
  align?: "left" | "center" | "right";
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({ size, delay = 0, exitAt, weight = theme.weights.hero, color = theme.colors.text, align = "left", style, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  const out =
    exitAt === undefined
      ? 0
      : interpolate(frame, [exitAt, exitAt + 9], [0, 1], { easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const pad = Math.round(size * 0.22);
  return (
    <div style={{ overflow: "hidden", paddingTop: pad, paddingBottom: pad, marginTop: -pad, marginBottom: -pad, ...style }}>
      <div
        style={{
          fontFamily: theme.fonts.display,
          fontWeight: weight,
          fontSize: size,
          lineHeight: theme.lineHeight,
          letterSpacing: 0,
          color,
          textAlign: align,
          whiteSpace: "nowrap",
          transform: `translateY(${interpolate(p, [0, 1], [112, 0]) - out * 112}%)`,
          opacity: clamp01(p * 2) * (1 - out),
        }}
      >
        {children}
      </div>
    </div>
  );
};

/** Highlight bar that sweeps in behind a word (word itself should be rendered above it). */
export const SweepWord: React.FC<{
  text: string;
  size: number;
  delay?: number;
  barColor: string;
  textColor: string;
  baseColor: string;
  weight?: number;
}> = ({ text, size, delay = 0, barColor, textColor, baseColor, weight = theme.weights.hero }) => {
  const frame = useCurrentFrame();
  const sweep = interpolate(frame, [delay + 8, delay + 22], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <span style={{ position: "relative", display: "inline-block", padding: `0 ${Math.round(size * 0.18)}px` }}>
      <span
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: "10%",
          bottom: "6%",
          borderRadius: Math.round(size * 0.16),
          background: barColor,
          transformOrigin: "0% 50%",
          transform: `scaleX(${sweep})`,
        }}
      />
      <span
        style={{
          position: "relative",
          fontFamily: theme.fonts.display,
          fontWeight: weight,
          fontSize: size,
          lineHeight: theme.lineHeight,
          letterSpacing: 0,
          color: sweep > 0.55 ? textColor : baseColor,
          whiteSpace: "nowrap",
        }}
      >
        {text}
      </span>
    </span>
  );
};
