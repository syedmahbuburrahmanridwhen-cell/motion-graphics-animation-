import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { theme } from "./theme";
import { SceneId, scenes } from "./timing";
import { BgMesh, Grade, Grain, Vignette } from "./components/Backdrop";
import { PreviewAudio } from "./components/PreviewAudio";
import { HookScene } from "./scenes/HookScene";
import { CompareScene } from "./scenes/CompareScene";
import { IntroScene } from "./scenes/IntroScene";
import { QuestionScene } from "./scenes/QuestionScene";
import { BuildScene } from "./scenes/BuildScene";
import { FeaturesScene } from "./scenes/FeaturesScene";
import { SubscribeScene } from "./scenes/SubscribeScene";
import { OutroScene } from "./scenes/OutroScene";

const SCENE_COMPONENTS: Record<SceneId, React.FC> = {
  hook: HookScene,
  compare: CompareScene,
  intro: IntroScene,
  question: QuestionScene,
  build: BuildScene,
  features: FeaturesScene,
  subscribe: SubscribeScene,
  outro: OutroScene,
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: theme.colors.bg }}>
    {/* 1 background mesh */}
    <BgMesh />
    {/* 2-3 assets + graphics (one Sequence per scene, boundaries come from the SRT) */}
    {scenes.map((s) => {
      const Scene = SCENE_COMPONENTS[s.id];
      return (
        <Sequence key={s.id} from={s.from} durationInFrames={s.dur} name={s.id}>
          <Scene />
        </Sequence>
      );
    })}
    {/* 4 grade, 5 grain + vignette */}
    <Grade />
    <Grain />
    <Vignette />
    <PreviewAudio />
  </AbsoluteFill>
);
