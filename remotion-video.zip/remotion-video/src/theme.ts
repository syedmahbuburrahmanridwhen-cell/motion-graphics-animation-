// theme.ts — single source of truth. No hex colors, easings or spring configs anywhere else.
import { Easing } from "remotion";
import { fontFamily } from "./fonts";

const stack = `${fontFamily}, "Noto Sans Bengali", "Hind Siliguri", sans-serif`;

export const theme = {
  colors: {
    // Scheme 1 — Shadow Mono
    bg: "#0B0C0E",
    bgAlt: "#131418",
    primary: "#FFFFFF", // THE hero color: max one hero element per frame
    accent: "#9AA1AD",
    text: "#F2F3F5",
    textDim: "#9AA1AD",
    textFaint: "#5B616C",
    // derived neutrals
    surface: "rgba(255,255,255,0.05)",
    surfaceStrong: "rgba(255,255,255,0.09)",
    hairline: "rgba(255,255,255,0.13)",
    glow: "rgba(255,255,255,0.34)",
    glowSoft: "rgba(255,255,255,0.10)",
    shadow: "rgba(0,0,0,0.62)",
    // inverted (light) flash used once in the hook
    inv: { bg: "#F2F3F5", text: "#0B0C0E", dim: "#4B505A" },
  },
  fonts: { display: stack, body: stack },
  weights: { hero: 700, semi: 600, body: 500 },
  // Bengali needs more line-height than Latin so matras are never clipped.
  lineHeight: 1.32,
  radius: { sm: 16, md: 28, lg: 44, pill: 999 },
  shadow: {
    card: "0 40px 80px -24px rgba(0,0,0,0.65), inset 0 1px 0 rgba(255,255,255,0.12)",
    soft: "0 24px 50px -20px rgba(0,0,0,0.6)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  // motion personality shared by every scene
  motion: { rise: 36, popScale: 0.92, blur: 10, wordGap: 3 },
} as const;
