// Project-wide switches. Everything else (colors, easing, fonts) lives in theme.ts.
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const FPS = 30;

// Voiceover preview: if public/voiceover.mp3 exists it plays in Remotion Studio.
export const VOICEOVER_PREVIEW = true;
// Default OFF for renders. Set to true to bake public/voiceover.mp3 into out/video.mp4.
export const VOICEOVER_IN_RENDER = false;

// Short UI sound effects in public/sfx (these are part of the render).
export const SFX_ENABLED = true;
