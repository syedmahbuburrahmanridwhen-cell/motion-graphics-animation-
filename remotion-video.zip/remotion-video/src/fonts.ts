import { loadFont } from "@remotion/google-fonts/HindSiliguri";

// Hind Siliguri: correct Bengali conjuncts (যুক্তাক্ষর) + Latin glyphs, so one family for the whole video.
export const { fontFamily } = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});
