import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { sceneById } from "../timing";
import { SceneShell } from "../components/SceneShell";
import { Float, MaskLine, Pop, useSpring } from "../components/Motion";
import { BrowserFrame, IconCursor } from "../components/Ui";
import { Sfx } from "../components/Sfx";

const c = theme.colors;
const t = sceneById("build");
const BX = 310;
const BY = 290;
const BW = 1300;
const BH = 640;

type B = { x: number; y: number; w: number; h: number; r?: number; fill?: string };
// Build order: nav, headline, sub-headline, text, image, button, three cards
const BLOCKS: B[] = [
  { x: 40, y: 22, w: 1220, h: 56, r: 16 },
  { x: 60, y: 116, w: 560, h: 36, r: 18, fill: c.text },
  { x: 60, y: 166, w: 430, h: 36, r: 18, fill: c.text },
  { x: 60, y: 222, w: 500, h: 18, r: 9, fill: c.textFaint },
  { x: 700, y: 104, w: 520, h: 236, r: 26, fill: c.glowSoft },
  { x: 60, y: 262, w: 200, h: 60, r: 30, fill: c.primary },
  { x: 60, y: 380, w: 380, h: 150, r: 22 },
  { x: 460, y: 380, w: 380, h: 150, r: 22 },
  { x: 860, y: 380, w: 360, h: 150, r: 22 },
];

const WBlock: React.FC<{ b: B; at: number }> = ({ b, at }) => {
  const frame = useCurrentFrame();
  const p = useSpring(at, "snappy");
  const fillP = interpolate(frame, [at + 8, at + 20], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const base: React.CSSProperties = { position: "absolute", left: b.x, top: b.y, width: b.w, height: b.h, borderRadius: b.r ?? 14, boxSizing: "border-box" };
  return (
    <div style={{ ...base, opacity: Math.min(1, p * 1.5), transform: `scale(${interpolate(p, [0, 1], [0.94, 1])})` }}>
      <div style={{ position: "absolute", inset: 0, borderRadius: b.r ?? 14, border: `2px dashed ${c.textFaint}`, opacity: 1 - fillP }} />
      <div style={{ position: "absolute", inset: 0, borderRadius: b.r ?? 14, background: b.fill ?? c.surfaceStrong, border: b.fill ? undefined : `1px solid ${c.hairline}`, opacity: fillP }} />
    </div>
  );
};

export const BuildScene: React.FC = () => {
  const frame = useCurrentFrame();
  const aAt = t.at(7, 0, 2);
  const bAt = t.at(7, 1, 2);
  const start = 16;
  const step = Math.floor((t.len(7) * 0.78) / BLOCKS.length);
  const times = BLOCKS.map((_, i) => start + i * step);

  // cursor glides to each block just before it appears
  const cx = interpolate(frame, [0, ...times.map((x) => x - 4)], [BW / 2, ...BLOCKS.map((b) => b.x + b.w / 2)], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const cy = interpolate(frame, [0, ...times.map((x) => x - 4)], [BH / 2, ...BLOCKS.map((b) => b.y + b.h / 2)], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const last = times[times.length - 1];
  const cursorOut = interpolate(frame, [last + 14, last + 26], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const shine = interpolate(frame, [last + 14, last + 40], [-40, 140], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const btnAt = times[5];
  const press = interpolate(frame, [btnAt + 4, btnAt + 8, btnAt + 14], [1, 0.9, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });

  return (
    <SceneShell id="build">
      {/* title swaps with a line-mask reveal */}
      <div style={{ position: "absolute", left: 0, width: 1920, top: 96, height: 150 }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 0, textAlign: "center" }}>
          <MaskLine size={116} delay={aAt} exitAt={bAt - 8} align="center">
            বানিয়ে দেখাব
          </MaskLine>
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 0, textAlign: "center" }}>
          <MaskLine size={116} delay={bAt} align="center">
            <span style={{ color: c.textDim }}>একদম </span>
            <span
              style={{
                backgroundImage: `linear-gradient(180deg, ${c.primary} 35%, ${c.accent})`,
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                color: "transparent",
                WebkitTextFillColor: "transparent",
              }}
            >
              শূন্য থেকে
            </span>
          </MaskLine>
        </div>
      </div>

      {/* empty canvas that builds itself */}
      <div style={{ position: "absolute", left: BX, top: BY }}>
        <Float amp={4} phase={1}>
          <Pop delay={aAt + 2} y={50} from={0.94}>
            <BrowserFrame width={BW} height={BH}>
              <div style={{ position: "absolute", inset: 0, backgroundImage: `radial-gradient(${c.textFaint} 1.4px, transparent 1.6px)`, backgroundSize: "36px 36px", opacity: 0.28 }} />
              {BLOCKS.map((b, i) => (
                <WBlock key={i} b={b} at={times[i]} />
              ))}
              {/* shine sweep once the site is complete */}
              <div
                style={{
                  position: "absolute",
                  top: 0,
                  bottom: 0,
                  left: `${shine}%`,
                  width: "22%",
                  background: `linear-gradient(100deg, transparent, ${c.glowSoft}, transparent)`,
                  transform: "skewX(-16deg)",
                }}
              />
              <div style={{ position: "absolute", left: cx - 6, top: cy - 4, opacity: cursorOut, transform: `scale(${frame > btnAt + 3 && frame < btnAt + 16 ? press : 1})` }}>
                <IconCursor size={50} />
              </div>
            </BrowserFrame>
          </Pop>
        </Float>
      </div>

      <Sfx name="whoosh" at={aAt} volume={0.2} />
      <Sfx name="pop" at={times[4]} volume={0.25} />
      <Sfx name="click" at={times[5] + 4} volume={0.3} />
      <Sfx name="pop" at={times[6]} volume={0.24} rate={1.05} />
      <Sfx name="pop" at={times[7]} volume={0.24} rate={1.12} />
    </SceneShell>
  );
};
