import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { sceneById } from "../timing";
import { SceneShell } from "../components/SceneShell";
import { Float, Pop, Words, useSpring } from "../components/Motion";
import { Avatar, GlassCard, IconBell, IconCheck } from "../components/Ui";
import { Sfx } from "../components/Sfx";

const c = theme.colors;
const t = sceneById("subscribe");
const LINE_X0 = 260;
const LINE_X1 = 1660;
const LINE_Y = 880;

const label: React.CSSProperties = { fontFamily: theme.fonts.display, fontWeight: theme.weights.hero, lineHeight: theme.lineHeight, letterSpacing: 0, whiteSpace: "nowrap" };

export const SubscribeScene: React.FC = () => {
  const frame = useCurrentFrame();
  const headAt = t.at(10, 0, 3);
  const cardAt = t.at(10, 1, 3);
  const nextAt = t.at(10, 2, 3);
  const pressAt = cardAt + 30;
  const done = interpolate(frame, [pressAt + 3, pressAt + 9], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const press = interpolate(frame, [pressAt - 4, pressAt, pressAt + 8], [1, 0.93, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const draw = interpolate(frame, [pressAt + 6, pressAt + 20], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const bell = useSpring(pressAt + 8, "bouncy");
  const ring = Math.sin(frame / 2.4) * 10 * Math.min(1, bell) * interpolate(frame, [pressAt + 10, pressAt + 40], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const lineDraw = interpolate(frame, [cardAt + 18, nextAt], [0, 1], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const node2 = useSpring(nextAt, "bouncy");
  const node1 = useSpring(cardAt + 14, "snappy");
  const travel = ((frame * 0.012) % 1) * (LINE_X1 - LINE_X0);

  return (
    <SceneShell id="subscribe">
      <div style={{ position: "absolute", left: 0, width: 1920, top: 100, display: "flex", justifyContent: "center" }}>
        <Words parts={["পুরো", { t: "Journey", grad: true }]} size={132} align="center" delay={headAt} />
      </div>

      {/* channel card with the profile picture and a Subscribe button */}
      <div style={{ position: "absolute", left: 380, top: 330 }}>
        <Float amp={4}>
          <Pop delay={cardAt} y={60} from={0.92}>
            <GlassCard width={1160} height={250} radius={theme.radius.lg}>
              <div style={{ position: "absolute", left: 60, top: 40 }}>
                <Avatar size={170} scene="subscribe" glow={false} />
              </div>
              <div style={{ position: "absolute", left: 290, top: 58, ...label, fontSize: 64, color: c.text }}>Channel</div>
              <div style={{ position: "absolute", left: 296, top: 142, opacity: Math.min(1, bell * 1.5), transform: `rotate(${ring}deg) scale(${interpolate(bell, [0, 1], [0.4, 1])})`, transformOrigin: "50% 10%" }}>
                <IconBell size={52} color={c.textDim} />
              </div>
              <div
                style={{
                  position: "absolute",
                  left: 640,
                  top: 69,
                  width: 460,
                  height: 112,
                  borderRadius: 56,
                  background: done > 0.5 ? c.surfaceStrong : c.primary,
                  border: `1px solid ${c.hairline}`,
                  transform: `scale(${press})`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  columnGap: 18,
                }}
              >
                {done > 0.5 && <IconCheck size={46} color={c.text} draw={draw} />}
                <span style={{ ...label, fontSize: 52, color: done > 0.5 ? c.text : c.bg }}>{done > 0.5 ? "Subscribed" : "Subscribe"}</span>
              </div>
            </GlassCard>
          </Pop>
        </Float>
      </div>

      {/* journey: this video -> next video */}
      <div style={{ position: "absolute", left: LINE_X0, top: LINE_Y - 2, width: LINE_X1 - LINE_X0, height: 4, borderRadius: 2, background: c.hairline }} />
      <div
        style={{
          position: "absolute",
          left: LINE_X0,
          top: LINE_Y - 2,
          width: LINE_X1 - LINE_X0,
          height: 4,
          borderRadius: 2,
          background: c.text,
          transformOrigin: "0% 50%",
          transform: `scaleX(${lineDraw})`,
        }}
      />
      <div style={{ position: "absolute", left: LINE_X0 + travel - 7, top: LINE_Y - 7, width: 14, height: 14, borderRadius: 7, background: c.textDim, opacity: lineDraw > 0.98 ? 0 : 0.9 * lineDraw }} />
      <div style={{ position: "absolute", left: LINE_X0 - 20, top: LINE_Y - 20, width: 40, height: 40, borderRadius: 20, background: c.text, opacity: Math.min(1, node1 * 1.5), transform: `scale(${interpolate(node1, [0, 1], [0.3, 1])})` }} />
      <div
        style={{
          position: "absolute",
          left: LINE_X1 - 26,
          top: LINE_Y - 26,
          width: 52,
          height: 52,
          borderRadius: 26,
          background: c.primary,
          boxShadow: `0 0 60px ${c.glow}`,
          opacity: Math.min(1, node2 * 1.5),
          transform: `scale(${interpolate(node2, [0, 1], [0.3, 1])})`,
        }}
      />
      <div style={{ position: "absolute", left: LINE_X0 - 130, width: 260, top: LINE_Y + 44, textAlign: "center", ...label, fontSize: 52, color: c.textDim, opacity: Math.min(1, node1 * 1.5) }}>এই Video</div>
      <div style={{ position: "absolute", left: LINE_X1 - 180, width: 360, top: LINE_Y + 44, textAlign: "center", ...label, fontSize: 56, color: c.text, opacity: Math.min(1, node2 * 1.5), transform: `translateY(${interpolate(node2, [0, 1], [24, 0])}px)` }}>
        পরের Video
      </div>

      <Sfx name="whoosh" at={headAt} volume={0.2} />
      <Sfx name="pop" at={cardAt} volume={0.26} />
      <Sfx name="click" at={pressAt - 1} volume={0.3} />
      <Sfx name="chime" at={pressAt + 6} volume={0.26} />
      <Sfx name="whoosh" at={cardAt + 20} volume={0.16} rate={1.1} />
      <Sfx name="pop" at={nextAt} volume={0.24} rate={1.1} />
    </SceneShell>
  );
};
