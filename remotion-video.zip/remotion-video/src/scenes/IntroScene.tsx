import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { sceneById } from "../timing";
import { SceneShell } from "../components/SceneShell";
import { Float, Pop, Words, useSpring } from "../components/Motion";
import { Avatar, GlassCard, IconCode, IconPhone } from "../components/Ui";
import { Sfx } from "../components/Sfx";

const c = theme.colors;
const t = sceneById("intro");

const RoleCard: React.FC<{ top: number; delay: number; label: string; icon: React.ReactNode }> = ({ top, delay, label, icon }) => (
  <div style={{ position: "absolute", left: 1000, top }}>
    <Float amp={4} phase={top / 100}>
      <Pop delay={delay} x={90} y={0} from={0.94} preset="smooth">
        <GlassCard width={800} height={170} style={{ display: "flex", alignItems: "center", columnGap: 36, paddingLeft: 38 }}>
          <div
            style={{
              width: 100,
              height: 100,
              borderRadius: 28,
              background: c.surfaceStrong,
              border: `1px solid ${c.hairline}`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            {icon}
          </div>
          <Words parts={label.split(" ")} size={72} delay={delay + 6} />
        </GlassCard>
      </Pop>
    </Float>
  </div>
);

export const IntroScene: React.FC = () => {
  const frame = useCurrentFrame();
  const webAt = t.at(5, 0, 3);
  const appAt = t.at(5, 1, 3);
  const askAt = t.at(5, 2, 3);
  const av = useSpring(0, "bouncy");
  const q = useSpring(askAt, "bouncy");
  const wiggle = Math.sin(frame / 5) * 3 * Math.min(1, q);

  return (
    <SceneShell id="intro">
      {/* profile picture — the one glowing element of this scene */}
      <div style={{ position: "absolute", left: 260, top: 280 }}>
        <Float amp={7} period={40}>
          <div style={{ opacity: Math.min(1, av * 1.5), transform: `scale(${interpolate(av, [0, 1], [0.6, 1])})` }}>
            <Avatar size={520} scene="intro" />
          </div>
        </Float>
      </div>

      {/* "ভাইয়া ... জিজ্ঞেস করেন" speech bubble */}
      <div style={{ position: "absolute", left: 770, top: 170, opacity: Math.min(1, q * 1.5), transform: `scale(${interpolate(q, [0, 1], [0.3, 1])}) rotate(${wiggle}deg)` }}>
        <GlassCard width={150} height={150} radius={75} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
          <span style={{ fontFamily: theme.fonts.display, fontWeight: theme.weights.hero, fontSize: 104, lineHeight: 1.2, color: c.text }}>?</span>
        </GlassCard>
      </div>

      <div style={{ position: "absolute", left: 1000, top: 250 }}>
        <Pop delay={4} y={24}>
          <div
            style={{
              display: "inline-block",
              padding: "6px 30px",
              borderRadius: theme.radius.pill,
              border: `1px solid ${c.hairline}`,
              background: c.surface,
              fontFamily: theme.fonts.display,
              fontWeight: theme.weights.semi,
              fontSize: 40,
              lineHeight: theme.lineHeight,
              color: c.textDim,
            }}
          >
            Professional
          </div>
        </Pop>
      </div>

      <RoleCard top={340} delay={webAt} label="Web Developer" icon={<IconCode size={58} />} />
      <RoleCard top={550} delay={appAt} label="App Builder" icon={<IconPhone size={58} />} />

      <Sfx name="chime" at={0} volume={0.28} />
      <Sfx name="pop" at={webAt} volume={0.26} />
      <Sfx name="pop" at={appAt} volume={0.26} rate={1.07} />
      <Sfx name="pop" at={askAt} volume={0.22} rate={1.15} />
    </SceneShell>
  );
};
