import React from "react";
import { interpolate } from "remotion";
import { theme } from "../theme";
import { sceneById } from "../timing";
import { SceneShell } from "../components/SceneShell";
import { Float, Words, useSpring } from "../components/Motion";
import { Avatar } from "../components/Ui";
import { Sfx } from "../components/Sfx";

const c = theme.colors;
const t = sceneById("outro");

export const OutroScene: React.FC = () => {
  const av = useSpring(0, "bouncy");
  const w0 = t.at(11, 0, 3) + 8;

  return (
    <SceneShell id="outro" exit={false}>
      <div style={{ position: "absolute", left: 960 - 170, top: 190 }}>
        <Float amp={5} period={38}>
          <div style={{ opacity: Math.min(1, av * 1.5), transform: `scale(${interpolate(av, [0, 1], [0.6, 1])})` }}>
            <Avatar size={340} scene="outro" />
          </div>
        </Float>
      </div>
      <div style={{ position: "absolute", left: 0, width: 1920, top: 590, display: "flex", flexDirection: "column", alignItems: "center" }}>
        <Words parts={["সরাসরি"]} size={58} weight={theme.weights.semi} color={c.textDim} align="center" delay={w0} />
        <Words parts={[{ t: "Website", grad: true }, "তৈরি", "শুরু"]} size={132} align="center" delay={w0 + 4} />
      </div>
      <Sfx name="chime" at={0} volume={0.28} />
      <Sfx name="whoosh" at={w0 - 2} volume={0.2} />
      <Sfx name="thud" at={w0 + 8} volume={0.22} rate={0.95} />
    </SceneShell>
  );
};
