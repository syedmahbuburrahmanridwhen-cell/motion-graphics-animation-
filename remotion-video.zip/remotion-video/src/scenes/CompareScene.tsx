import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { sceneById } from "../timing";
import { SceneShell } from "../components/SceneShell";
import { Float, Pop, Words, useSpring } from "../components/Motion";
import { Block, BrowserFrame, GlassCard, IconShield } from "../components/Ui";
import { Sfx } from "../components/Sfx";

const c = theme.colors;
const t = sceneById("compare");
const PW = 800;
const PH = 660;
const PY = 130;
const LX = 110;
const RX = 1010;

const ease01 = (frame: number, a: number, b: number) =>
  interpolate(frame, [a, b], [0, 1], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });

/** Ordinary social-page skeleton (the "before"). */
const FeedSkeleton: React.FC<{ delay: number }> = ({ delay }) => (
  <div style={{ position: "relative", width: 712, height: 330, opacity: 0.8 }}>
    <Pop delay={delay} y={24} style={{ position: "absolute", left: 0, top: 0 }}>
      <Block w={712} h={96} r={18} fill={c.surface} style={{ border: `1px solid ${c.hairline}` }} />
    </Pop>
    <Pop delay={delay + 5} y={24} style={{ position: "absolute", left: 24, top: 56 }}>
      <Block w={84} h={84} r={42} fill={c.textFaint} style={{ border: `4px solid ${c.bgAlt}` }} />
    </Pop>
    <Pop delay={delay + 8} y={20} style={{ position: "absolute", left: 128, top: 116 }}>
      <Block w={230} h={18} r={9} fill={c.surfaceStrong} />
      <Block w={150} h={12} r={6} fill={c.surface} style={{ marginTop: 12 }} />
    </Pop>
    {[0, 1].map((i) => (
      <Pop key={i} delay={delay + 13 + i * 5} y={26} style={{ position: "absolute", left: i * 366, top: 176 }}>
        <Block w={346} h={150} r={18} fill={c.surface} style={{ border: `1px solid ${c.hairline}`, padding: 22, boxSizing: "border-box" }}>
          <Block w="70%" h={14} r={7} fill={c.surfaceStrong} />
          <Block w="48%" h={14} r={7} fill={c.surface} style={{ marginTop: 14 }} />
          <Block w="82%" h={14} r={7} fill={c.surface} style={{ marginTop: 14 }} />
        </Block>
      </Pop>
    ))}
  </div>
);

/** Polished mini-site (the "after"). */
const SiteMock: React.FC<{ delay: number }> = ({ delay }) => {
  const frame = useCurrentFrame();
  const bob = Math.sin(frame / 18) * 4;
  return (
    <div style={{ position: "relative", width: 712, height: 324 }}>
      <Pop delay={delay} y={16} style={{ position: "absolute", left: 22, top: 14, display: "flex", alignItems: "center", gap: 14, width: 668 }}>
        <Block w={28} h={28} r={14} fill={c.text} />
        <div style={{ flex: 1 }} />
        {[0, 1, 2, 3].map((i) => (
          <Block key={i} w={58} h={12} r={6} fill={c.surfaceStrong} />
        ))}
      </Pop>
      <Pop delay={delay + 5} style={{ position: "absolute", left: 24, top: 76 }}>
        <Block w={340} h={26} r={13} fill={c.text} />
      </Pop>
      <Pop delay={delay + 9} style={{ position: "absolute", left: 24, top: 116 }}>
        <Block w={250} h={26} r={13} fill={c.text} />
      </Pop>
      <Pop delay={delay + 13} style={{ position: "absolute", left: 24, top: 164 }}>
        <Block w={310} h={11} r={6} fill={c.textFaint} />
        <Block w={240} h={11} r={6} fill={c.textFaint} style={{ marginTop: 10 }} />
      </Pop>
      <Pop delay={delay + 18} preset="bouncy" style={{ position: "absolute", left: 24, top: 212 }}>
        <Block w={150} h={44} r={22} fill={c.primary} />
      </Pop>
      <Pop delay={delay + 12} y={30} style={{ position: "absolute", left: 420, top: 66 + bob }}>
        <Block w={270} h={168} r={20} fill={`linear-gradient(135deg, ${c.surfaceStrong}, ${c.glowSoft})`} style={{ border: `1px solid ${c.hairline}`, position: "relative" }}>
          <div style={{ position: "absolute", right: 34, top: 28, width: 46, height: 46, borderRadius: 23, background: c.glowSoft }} />
          <div style={{ position: "absolute", left: 26, bottom: 24, width: 130, height: 12, borderRadius: 6, background: c.hairline }} />
        </Block>
      </Pop>
      {[0, 1, 2].map((i) => (
        <Pop key={i} delay={delay + 24 + i * 5} y={26} style={{ position: "absolute", left: 24 + i * 226, top: 258 }}>
          <Block w={212} h={56} r={16} fill={c.surface} style={{ border: `1px solid ${c.hairline}` }} />
        </Pop>
      ))}
    </div>
  );
};

export const CompareScene: React.FC = () => {
  const frame = useCurrentFrame();
  const fbAt = t.at(3, 0, 2);
  const smAt = t.at(3, 1, 2);
  const siteAt = t.at(4, 0, 2);
  const trustAt = t.at(4, 1, 2);
  const d = ease01(frame, trustAt, trustAt + 22); // trust moment: left dims, right lights up
  const arrow = useSpring(siteAt, "bouncy");
  const draw = ease01(frame, trustAt + 10, trustAt + 28);

  return (
    <SceneShell id="compare">
      {/* ---------- LEFT: before ---------- */}
      <div style={{ position: "absolute", left: LX, top: PY, opacity: 1 - 0.55 * d, transform: `scale(${1 - 0.03 * d})`, filter: `blur(${1.6 * d}px)` }}>
        <Float amp={5} phase={0.5}>
          <Pop delay={fbAt} y={50} preset="smooth">
            <GlassCard width={PW} height={PH} style={{ border: `1px dashed ${c.hairline}` }}>
              <div style={{ position: "absolute", left: 44, top: 34 }}>
                <Words parts={["Facebook", "page"]} size={64} delay={fbAt + 4} />
                <Words parts={[{ t: "বা", dim: true }]} size={52} weight={theme.weights.semi} delay={smAt + 2} style={{ marginTop: -6 }} />
                <Words parts={["Social", "media", "account"]} size={64} delay={smAt + 4} style={{ marginTop: -6 }} />
              </div>
              <div style={{ position: "absolute", left: 44, top: 292 }}>
                <FeedSkeleton delay={fbAt + 12} />
              </div>
            </GlassCard>
          </Pop>
        </Float>
      </div>

      {/* ---------- CENTER: transition arrow ---------- */}
      <div
        style={{
          position: "absolute",
          left: 960 - 40,
          top: PY + PH / 2 - 40,
          width: 80,
          height: 80,
          borderRadius: 40,
          background: c.surfaceStrong,
          border: `1px solid ${c.hairline}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          opacity: Math.min(1, arrow * 1.5),
          transform: `scale(${interpolate(arrow, [0, 1], [0.4, 1])})`,
        }}
      >
        <svg width="40" height="40" viewBox="0 0 48 48" fill="none" stroke={c.text} strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M8 24 H38 M27 13 L38 24 L27 35" />
        </svg>
      </div>

      {/* ---------- RIGHT: after ---------- */}
      <div style={{ position: "absolute", left: RX, top: PY }}>
        <Float amp={5} phase={2}>
          <Pop delay={siteAt} y={50}>
            <GlassCard width={PW} height={PH} style={{ boxShadow: `${theme.shadow.card}, 0 0 ${70 * d}px ${c.glow}`, border: `1px solid ${c.hairline}` }}>
              <div style={{ position: "absolute", left: 44, top: 34 }}>
                <Words parts={["Professional"]} size={64} delay={siteAt + 4} />
                <Words parts={[{ t: "Website", grad: true }]} size={64} delay={siteAt + 8} style={{ marginTop: -6 }} />
              </div>
              <BrowserFrame width={712} height={382} style={{ position: "absolute", left: 44, top: 226 }}>
                <SiteMock delay={siteAt + 12} />
              </BrowserFrame>
            </GlassCard>
          </Pop>
        </Float>
      </div>

      {/* ---------- trust banner ---------- */}
      <div style={{ position: "absolute", left: 360, top: 860 }}>
        <Pop delay={trustAt} y={40}>
          <GlassCard width={1200} height={120} radius={theme.radius.pill} style={{ display: "flex", alignItems: "center", justifyContent: "center", columnGap: 28 }}>
            <IconShield size={64} draw={draw} />
            <Words parts={["Brand", "অনেক", "বেশি", { t: "নির্ভরযোগ্য", grad: true }]} size={60} delay={trustAt + 4} gap={20} align="center" />
          </GlassCard>
        </Pop>
      </div>

      <Sfx name="pop" at={fbAt} volume={0.26} />
      <Sfx name="pop" at={smAt} volume={0.24} rate={1.08} />
      <Sfx name="whoosh" at={siteAt} volume={0.2} />
      <Sfx name="pop" at={siteAt + 12} volume={0.26} rate={0.95} />
      <Sfx name="click" at={trustAt + 8} volume={0.3} />
    </SceneShell>
  );
};
