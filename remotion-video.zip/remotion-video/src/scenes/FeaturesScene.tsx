import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { sceneById } from "../timing";
import { SceneShell } from "../components/SceneShell";
import { Float, Pop, Words, useSpring } from "../components/Motion";
import { Block, BrowserFrame, GlassCard, IconCursor, IconPlay } from "../components/Ui";
import { Sfx } from "../components/Sfx";

const c = theme.colors;
const t = sceneById("features");

type Tile = { x: number; y: number; w: number; h: number };
const A: Tile = { x: 120, y: 120, w: 828, h: 408 };
const E: Tile = { x: 120, y: 552, w: 828, h: 408 };
const B: Tile = { x: 972, y: 120, w: 402, h: 840 };
const C: Tile = { x: 1398, y: 120, w: 402, h: 408 };
const D: Tile = { x: 1398, y: 552, w: 402, h: 408 };

const TileBox: React.FC<{ tile: Tile; at: number; phase: number; children: React.ReactNode }> = ({ tile, at, phase, children }) => (
  <div style={{ position: "absolute", left: tile.x, top: tile.y }}>
    <Float amp={4} phase={phase} scale={0.004}>
      <Pop delay={at} y={60} from={0.9} blur={10}>
        <GlassCard width={tile.w} height={tile.h} radius={theme.radius.md}>
          {children}
        </GlassCard>
      </Pop>
    </Float>
  </div>
);

const Phone: React.FC<{ delay: number }> = ({ delay }) => (
  <div style={{ width: 240, height: 470, borderRadius: 44, border: `3px solid ${c.hairline}`, background: c.bgAlt, boxShadow: theme.shadow.soft, position: "relative", overflow: "hidden" }}>
    <div style={{ position: "absolute", left: 80, top: 12, width: 80, height: 14, borderRadius: 7, background: c.surfaceStrong }} />
    <Pop delay={delay} y={20} style={{ position: "absolute", left: 22, top: 54 }}>
      <Block w={196} h={26} r={13} fill={c.text} />
    </Pop>
    <Pop delay={delay + 4} y={20} style={{ position: "absolute", left: 22, top: 98 }}>
      <Block w={196} h={110} r={20} fill={c.glowSoft} style={{ border: `1px solid ${c.hairline}` }} />
    </Pop>
    {[0, 1, 2].map((i) => (
      <Pop key={i} delay={delay + 8 + i * 4} y={20} style={{ position: "absolute", left: 22, top: 226 + i * 62 }}>
        <Block w={196} h={50} r={16} fill={c.surfaceStrong} />
      </Pop>
    ))}
    <Pop delay={delay + 22} y={20} style={{ position: "absolute", left: 22, top: 418 }}>
      <Block w={196} h={34} r={17} fill={c.primary} />
    </Pop>
  </div>
);

const Ripple: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <>
      {[0, 1].map((i) => {
        const k = ((frame + i * 24) % 48) / 48;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: 201 - 70,
              top: 290 - 70,
              width: 140,
              height: 140,
              borderRadius: "50%",
              border: `2px solid ${c.hairline}`,
              opacity: 0.8 * (1 - k),
              transform: `scale(${1 + k * 0.9})`,
            }}
          />
        );
      })}
    </>
  );
};

export const FeaturesScene: React.FC = () => {
  const aAt = t.at(8, 0, 2);
  const eAt = t.at(8, 1, 2);
  const bAt = t.at(9, 0, 3);
  const cAt = t.at(9, 1, 3);
  const dAt = t.at(9, 2, 3);
  const bub1 = useSpring(dAt + 10, "bouncy");
  const bub2 = useSpring(dAt + 20, "bouncy");

  return (
    <SceneShell id="features">
      {/* A — next level website */}
      <TileBox tile={A} at={aAt} phase={0}>
        <div style={{ position: "absolute", left: 48, top: 30 }}>
          <Words parts={["Next", "Level"]} size={108} delay={aAt + 6} />
          <div style={{ display: "flex", alignItems: "baseline", columnGap: 30 }}>
            <Words parts={[{ t: "Website", grad: true }]} size={108} delay={aAt + 12} />
            <Words parts={[{ t: "তৈরি", dim: true }, { t: "করব", dim: true }]} size={56} weight={theme.weights.semi} delay={aAt + 18} />
          </div>
        </div>
      </TileBox>

      {/* E — premium websites */}
      <TileBox tile={E} at={eAt} phase={1}>
        <div style={{ position: "absolute", left: 48, top: 44 }}>
          <Words parts={["Premium"]} size={80} delay={eAt + 6} />
          <Words parts={[{ t: "Website", grad: true }]} size={80} delay={eAt + 11} />
        </div>
        <div style={{ position: "absolute", left: 420, top: 78, transform: "rotate(3deg)" }}>
          <BrowserFrame width={380} height={290}>
            <Pop delay={eAt + 12} y={16} style={{ position: "absolute", left: 20, top: 16 }}>
              <Block w={340} h={34} r={12} fill={c.surfaceStrong} />
            </Pop>
            <Pop delay={eAt + 17} y={16} style={{ position: "absolute", left: 20, top: 66 }}>
              <Block w={210} h={20} r={10} fill={c.text} />
            </Pop>
            <Pop delay={eAt + 21} y={16} style={{ position: "absolute", left: 20, top: 98 }}>
              <Block w={150} h={20} r={10} fill={c.text} />
            </Pop>
            <Pop delay={eAt + 25} y={16} style={{ position: "absolute", left: 242, top: 60 }}>
              <Block w={118} h={100} r={16} fill={c.glowSoft} />
            </Pop>
            {[0, 1].map((i) => (
              <Pop key={i} delay={eAt + 29 + i * 4} y={16} style={{ position: "absolute", left: 20 + i * 176, top: 150 }}>
                <Block w={164} h={62} r={14} fill={c.surface} style={{ border: `1px solid ${c.hairline}` }} />
              </Pop>
            ))}
          </BrowserFrame>
        </div>
      </TileBox>

      {/* B — app */}
      <TileBox tile={B} at={bAt} phase={2}>
        <div style={{ position: "absolute", left: 40, top: 34 }}>
          <Words parts={["App"]} size={110} delay={bAt + 6} />
        </div>
        <div style={{ position: "absolute", left: 81, top: 270 }}>
          <Phone delay={bAt + 10} />
        </div>
      </TileBox>

      {/* C — interactive demo */}
      <TileBox tile={C} at={cAt} phase={3}>
        <div style={{ position: "absolute", left: 36, top: 26 }}>
          <Words parts={["Interactive"]} size={54} delay={cAt + 6} />
          <Words parts={["Demo"]} size={54} delay={cAt + 10} />
        </div>
        <Ripple />
        <div
          style={{
            position: "absolute",
            left: 201 - 56,
            top: 290 - 56,
            width: 112,
            height: 112,
            borderRadius: 56,
            background: c.surfaceStrong,
            border: `1px solid ${c.hairline}`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <IconPlay size={52} />
        </div>
        <div style={{ position: "absolute", left: 232, top: 316 }}>
          <Float amp={6} period={22}>
            <IconCursor size={52} />
          </Float>
        </div>
      </TileBox>

      {/* D — contact */}
      <TileBox tile={D} at={dAt} phase={4}>
        <div style={{ position: "absolute", left: 36, top: 26 }}>
          <Words parts={["Contact"]} size={64} delay={dAt + 6} />
        </div>
        <div style={{ position: "absolute", left: 36, top: 168, opacity: Math.min(1, bub1 * 1.5), transform: `scale(${0.6 + 0.4 * Math.min(1.05, bub1)}) translateY(${(1 - Math.min(1, bub1)) * 20}px)`, transformOrigin: "0% 100%" }}>
          <Block w={250} h={74} r={26} fill={c.surfaceStrong} style={{ border: `1px solid ${c.hairline}`, padding: 20, boxSizing: "border-box" }}>
            <Block w="80%" h={12} r={6} fill={c.textFaint} />
            <Block w="52%" h={12} r={6} fill={c.textFaint} style={{ marginTop: 10 }} />
          </Block>
        </div>
        <div style={{ position: "absolute", left: 116, top: 262, opacity: Math.min(1, bub2 * 1.5), transform: `scale(${0.6 + 0.4 * Math.min(1.05, bub2)}) translateY(${(1 - Math.min(1, bub2)) * 20}px)`, transformOrigin: "100% 100%" }}>
          <Block w={250} h={74} r={26} fill={c.text} style={{ padding: 20, boxSizing: "border-box" }}>
            <Block w="76%" h={12} r={6} fill={c.bg} />
            <Block w="46%" h={12} r={6} fill={c.bg} style={{ marginTop: 10 }} />
          </Block>
        </div>
      </TileBox>

      <Sfx name="pop" at={aAt} volume={0.26} />
      <Sfx name="pop" at={eAt} volume={0.25} rate={1.06} />
      <Sfx name="pop" at={bAt} volume={0.26} rate={0.96} />
      <Sfx name="pop" at={cAt} volume={0.25} rate={1.1} />
      <Sfx name="pop" at={dAt} volume={0.25} rate={1.02} />
    </SceneShell>
  );
};
