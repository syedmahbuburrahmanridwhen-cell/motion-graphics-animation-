import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { sceneById } from "../timing";
import { SceneShell } from "../components/SceneShell";
import { Float, Pop, Words } from "../components/Motion";
import { GlassCard, IconBrowser, IconPhone } from "../components/Ui";
import { Sfx } from "../components/Sfx";

const c = theme.colors;
const t = sceneById("question");

const StrikeRow: React.FC<{ delay: number }> = ({ delay }) => {
  const frame = useCurrentFrame();
  const sweep = interpolate(frame, [delay + 16, delay + 32], [0, 1], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const base: React.CSSProperties = { fontFamily: theme.fonts.display, fontWeight: theme.weights.hero, fontSize: 80, lineHeight: theme.lineHeight, letterSpacing: 0 };
  return (
    <Pop delay={delay} y={30}>
      <div style={{ display: "flex", alignItems: "center", columnGap: 36, justifyContent: "center" }}>
        <span style={{ position: "relative", display: "inline-block", ...base, color: sweep > 0.5 ? c.textFaint : c.textDim, whiteSpace: "nowrap" }}>
          শুধু মুখে বলা
          <span
            style={{
              position: "absolute",
              left: -8,
              right: -8,
              top: "54%",
              height: 7,
              borderRadius: 4,
              background: c.primary,
              transformOrigin: "0% 50%",
              transform: `scaleX(${sweep})`,
            }}
          />
        </span>
        <span style={{ ...base, color: c.text, whiteSpace: "nowrap" }}>নয়</span>
      </div>
    </Pop>
  );
};

export const QuestionScene: React.FC = () => {
  const frame = useCurrentFrame();
  const askAt = t.at(6, 0, 2);
  const notAt = t.at(6, 1, 2);
  const ghost = interpolate(frame, [0, t.dur], [0.9, 1.08], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });

  return (
    <SceneShell id="question">
      <div style={{ position: "absolute", left: 180, top: 190 }}>
        <Float amp={4}>
          <Pop delay={0} y={60} from={0.9}>
            <GlassCard width={1560} height={700} radius={theme.radius.lg}>
              <div
                style={{
                  position: "absolute",
                  right: 60,
                  top: -90,
                  fontFamily: theme.fonts.display,
                  fontWeight: theme.weights.hero,
                  fontSize: 780,
                  lineHeight: 1.2,
                  color: c.text,
                  opacity: 0.045,
                  transform: `scale(${ghost})`,
                }}
              >
                ?
              </div>
              <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", rowGap: 6 }}>
                <Words parts={["আপনি", "ঠিক", "কেমন"]} size={58} weight={theme.weights.semi} color={c.textDim} align="center" delay={askAt + 4} />
                <Words parts={[{ t: "Website", grad: true }, { t: "বা", dim: true }, { t: "App", grad: true }]} size={156} align="center" delay={askAt + 10} />
                <Words parts={["তৈরি", "করতে", "পারেন?"]} size={92} align="center" delay={askAt + 22} />
                <div style={{ height: 22 }} />
                <StrikeRow delay={notAt} />
              </div>
            </GlassCard>
          </Pop>
        </Float>
      </div>

      {/* the two things they build: web + app */}
      <div style={{ position: "absolute", left: 96, top: 110 }}>
        <Float amp={8} period={30} phase={1}>
          <Pop delay={askAt + 14} preset="bouncy" from={0.5} y={20}>
            <div style={{ transform: "rotate(-8deg)" }}>
              <GlassCard width={170} height={150} radius={32} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                <IconBrowser size={84} />
              </GlassCard>
            </div>
          </Pop>
        </Float>
      </div>
      <div style={{ position: "absolute", left: 1670, top: 790 }}>
        <Float amp={8} period={32} phase={2.5}>
          <Pop delay={askAt + 20} preset="bouncy" from={0.5} y={20}>
            <div style={{ transform: "rotate(8deg)" }}>
              <GlassCard width={140} height={190} radius={32} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                <IconPhone size={92} />
              </GlassCard>
            </div>
          </Pop>
        </Float>
      </div>

      <Sfx name="whoosh" at={askAt} volume={0.22} />
      <Sfx name="pop" at={askAt + 14} volume={0.22} rate={1.05} />
      <Sfx name="pop" at={askAt + 20} volume={0.22} rate={1.14} />
      <Sfx name="click" at={notAt + 16} volume={0.3} />
    </SceneShell>
  );
};
