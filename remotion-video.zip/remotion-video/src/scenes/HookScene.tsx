import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { sceneById } from "../timing";
import { SceneShell } from "../components/SceneShell";
import { Float, Pop, SweepWord, Words, useSpring } from "../components/Motion";
import { Sfx } from "../components/Sfx";

const c = theme.colors;
const CX = 1480;
const CY = 540;
const t = sceneById("hook");

const Ring: React.FC<{ r: number; delay: number; speed: number }> = ({ r, delay, speed }) => {
  const frame = useCurrentFrame();
  const p = useSpring(delay, "smooth");
  return (
    <div
      style={{
        position: "absolute",
        left: CX - r,
        top: CY - r,
        width: r * 2,
        height: r * 2,
        borderRadius: "50%",
        border: `2px dashed ${c.textFaint}`,
        opacity: Math.min(1, p * 1.4) * 0.9,
        transform: `scale(${interpolate(p, [0, 1], [0.6, 1])}) rotate(${interpolate(p, [0, 1], [-50, 0]) + frame * speed}deg)`,
        boxSizing: "border-box",
      }}
    />
  );
};

const RingArt: React.FC = () => {
  const frame = useCurrentFrame();
  const p = useSpring(14, "bouncy");
  const ang = frame * 0.035;
  const R = 300;
  return (
    <>
      <Ring r={300} delay={0} speed={0.18} />
      <Ring r={220} delay={6} speed={-0.3} />
      <Ring r={140} delay={12} speed={0.45} />
      {/* core */}
      <div
        style={{
          position: "absolute",
          left: CX - 46,
          top: CY - 46,
          width: 92,
          height: 92,
          borderRadius: "50%",
          background: `radial-gradient(circle at 35% 30%, ${c.surfaceStrong}, ${c.surface})`,
          border: `2px solid ${c.hairline}`,
          opacity: Math.min(1, p * 1.5),
          transform: `scale(${interpolate(p, [0, 1], [0.3, 1 + Math.sin(frame / 20) * 0.03])})`,
        }}
      />
      {/* the one hero element: orbiting spark */}
      <div
        style={{
          position: "absolute",
          left: CX + Math.cos(ang) * R - 11,
          top: CY + Math.sin(ang) * R - 11,
          width: 22,
          height: 22,
          borderRadius: "50%",
          background: c.primary,
          boxShadow: `0 0 36px ${c.glow}`,
          opacity: Math.min(1, p * 1.5),
        }}
      />
    </>
  );
};

export const HookScene: React.FC = () => {
  const frame = useCurrentFrame();
  const wipe0 = t.at(2, 0, 3);
  const radius = interpolate(frame, [wipe0, wipe0 + 16], [0, 1750], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const inv = c.inv;
  const s = wipe0 + 7; // inverted words start once the wipe has opened

  return (
    <SceneShell id="hook">
      {/* ---- cue 1: dark kinetic stack + ring art ---- */}
      <AbsoluteFill>
        <RingArt />
        <div style={{ position: "absolute", left: 140, top: 150 }}>
          <Float amp={4} phase={0}>
            <Words parts={["আপনার"]} size={64} weight={theme.weights.semi} color={c.textDim} delay={t.at(1, 0, 4)} />
          </Float>
          <Float amp={4} phase={1}>
            <Words parts={["Business", { t: "বা", dim: true }]} size={132} delay={t.at(1, 1, 4)} />
          </Float>
          <Float amp={4} phase={2}>
            <Words parts={["Personal", { t: "Brand", grad: true }]} size={132} delay={t.at(1, 2, 4)} />
          </Float>
          <Float amp={4} phase={3}>
            <Words parts={[{ t: "চেহারা", grad: true }]} size={150} delay={t.at(1, 3, 4)} />
          </Float>
        </div>
      </AbsoluteFill>

      {/* ---- cue 2: light inverted statement, revealed by a circular wipe from the ring ---- */}
      <AbsoluteFill style={{ clipPath: `circle(${radius}px at ${CX}px ${CY}px)`, background: inv.bg }}>
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", flexDirection: "column", display: "flex" }}>
          <Float amp={5}>
            <Words parts={["এক", "নিমেষে"]} size={196} color={inv.text} align="center" delay={s} />
          </Float>
          <div style={{ display: "flex", alignItems: "center", columnGap: 44 }}>
            <Pop delay={t.at(2, 1, 3) + 7} y={30}>
              <SweepWord text="বদলে" size={196} delay={t.at(2, 1, 3) + 7} barColor={inv.text} textColor={inv.bg} baseColor={inv.text} />
            </Pop>
            <Words parts={["দিতে", "পারে"]} size={96} weight={theme.weights.semi} color={inv.dim} delay={t.at(2, 2, 3) + 7} />
          </div>
        </AbsoluteFill>
      </AbsoluteFill>

      {/* sound: soft thud on the hook, swipe + thud on the wipe */}
      <Sfx name="thud" at={0} volume={0.3} />
      <Sfx name="whoosh" at={t.at(1, 1, 4)} volume={0.2} />
      <Sfx name="swipe" at={wipe0} volume={0.26} />
      <Sfx name="thud" at={wipe0 + 8} volume={0.22} rate={1.12} />
    </SceneShell>
  );
};
